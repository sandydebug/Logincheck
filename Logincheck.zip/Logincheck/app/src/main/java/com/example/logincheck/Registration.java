package com.example.logincheck;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Registration extends AppCompatActivity {

    EditText editText1, editText2, editText3, editText4;
    TextView textView;
    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        intialize();
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(validate()){

                }

            }
        });

        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Registration.this,MainActivity.class));
            }
        });
    }

    private void intialize() {
        editText1 = (EditText) findViewById(R.id.etUserName);
        editText2 = (EditText) findViewById(R.id.etUserEmail);
        editText3 = (EditText) findViewById(R.id.etPassword);
        editText4 = (EditText) findViewById(R.id.etAge);
        textView = (TextView) findViewById(R.id.tvUserLogin);
        button = (Button) findViewById(R.id.btnRegister);


    }

    private boolean validate() {
        Boolean res=false;
        String name = editText1.getText().toString();
        String email = editText2.getText().toString();
        String password = editText3.getText().toString();

        if (name.isEmpty() || email.isEmpty() || password.isEmpty()) {
            Toast.makeText(Registration.this, "Enter all the details", Toast.LENGTH_SHORT).show();
        }
        else{
            res=true;}

        return res;

    }
}
